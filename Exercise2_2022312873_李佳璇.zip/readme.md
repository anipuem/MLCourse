# 1. Environment required:
Python3
# 2. Recommended package version:
sklearn——0.21.3
numpy——1.19.5
matplotlib——3.1.1
seaborn——0.12.0
plotly——5.10.0

# 3. Something need clarity:
### (1) Page limitation: 
As the report combines code are all in jupyter notebook('ML_Ex2.ipynb'), I extract the word part of jupyter notebook and paste into a word document, it shows that the words are within 4 pages.
### (2) Layout: 
The 'ML_Ex2.ipynb' included all the three experiments. You can click 'Cell' -->'Run all' to run all of them and then see the results.
And I have also make sure that each Experiment can run independently, but please run the **'# import libraries'** part (*located at the beginning of the document*) before run Experiment 1, run the **'# import libraries'** part and **'# import more libraries'** part (*located just above Experiment 2*) before run Experiment 2 and 3.
### (3) If you have any further questions, please contact me. (***1735323760, 2022312873-李佳璇***)
