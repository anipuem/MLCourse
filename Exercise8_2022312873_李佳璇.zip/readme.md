# 1. Environment required:
Python3
# 2. Recommended package version:
sklearn——0.21.3
numpy——1.19.5
matplotlib——3.1.1（option）
seaborn——0.12.0  （option）
plotly——5.10.0 （option）

# 3. Something need clarity:
### If you have any further questions, please contact me. (***1735323760, 2022312873-李佳璇***)
